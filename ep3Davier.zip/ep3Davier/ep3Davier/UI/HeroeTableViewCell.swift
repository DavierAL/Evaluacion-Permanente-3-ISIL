//
//  HeroeTableViewCell.swift
//  ep3Davier
//
//  Created by user213622 on 6/18/23.
//

import UIKit


class HeroeTableViewCell: UITableViewCell {

    @IBOutlet weak var imagen: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var fullname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}
